# Dalam file extensions.py atau database.py
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
